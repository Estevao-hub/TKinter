import tkinter as tk

janela = tk.Tk()

var_aviao = tk.StringVar()

btn_classeconomica = tk.Radiobutton(text="Class econômica", variable=var_aviao, value="Classe econômica")
btn_classexecutiva = tk.Radiobutton(text="Class executiva", variable=var_aviao, value="Classe executiva")
btn_primeiraclasse = tk.Radiobutton(text="Primeira classe", variable=var_aviao, value="Primeira classe")
btn_classeconomica.grid(row=0,column=0)
btn_classexecutiva.grid(row=0,column=1)
btn_primeiraclasse.grid(row=0,column=2)

def enviar():
    print(var_aviao.get())


botao_enviar = tk.Button(text="Enviar", command=enviar)
botao_enviar.grid(row=1,column=0)
tk.mainloop()